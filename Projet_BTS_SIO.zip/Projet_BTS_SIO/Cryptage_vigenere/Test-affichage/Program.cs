﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test_affichage
{
    class Program
    {
        static void Main(string[] args)
        {
            string alphabet = "abcdefghijklmnopqrstuvwxyz";
            int compte = 0;
            string[,] contenu = { };

               for(int i = 0; i<alphabet.Length; i++)
                {
                    for(int y = 0; y<alphabet.Length; y++)
                    {
                        contenu[i, y] = alphabet[i].ToString();
                    }
                }


            for (int i = 0; i < alphabet.Length; i++)
            {
                for (int y = 0; y < alphabet.Length; y++)
                {
                    Console.Write(contenu[i,y]);
                }
            }
            Console.ReadKey();
        }
    }
}
