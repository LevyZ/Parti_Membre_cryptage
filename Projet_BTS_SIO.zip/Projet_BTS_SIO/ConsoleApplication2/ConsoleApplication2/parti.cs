﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class parti
    {
        private string nom;
        private List<membre> LesMembres = new List<membre>(); 

        public parti(string unNom) {
            nom = unNom;
        }

        public parti()
        {
            nom = "Inconnu";
        }
        
        public string GivelesMembres ()
        {
            string gmembres = "";
            foreach(membre mb in LesMembres)
            {
                gmembres = gmembres + mb.GetName() + " ";
            }
            return (gmembres);
        }

        public void ajouterMembre(membre nmembre)
        {
            LesMembres.Add(nmembre);
        }
    }
}
