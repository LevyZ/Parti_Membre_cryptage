﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class Program
    {
        static string Vigenere (string mot)
        {
            string colettre = "";
            string test = "";
            string phrase = "";
            int indiph = 0;
            int i = 0;
            int z = 0;
            int coz = 0;
            string Recupercogi;
            string alpha = "abcdefghijklmnopqrstuvwxyz";
            string cogito = "cogito";

            phrase = mot;

            while (indiph < phrase.Length)

            {

                Recupercogi = cogito[coz].ToString();


                while (alpha[z].ToString() != Recupercogi)
                {
                    z = z + 1;

                }

                test = phrase[indiph].ToString();

                if (test == " ")
                {
                    indiph = indiph + 1;
                    colettre = colettre + " ";

                }
                else
                {
                    while (alpha[i].ToString() != test)
                    {
                        i = i + 1;
                    }

                    i = i + z;
                    if (i >= 26)
                    {
                        i = i - 26;
                    }
                    colettre = colettre + alpha[i].ToString();
                    z = 0;
                    i = 0;
                    indiph = indiph + 1;

                    coz = coz + 1;

                    if (coz >= 6)
                    {
                        coz = 0;
                    }
                }
            }

            return (colettre);
        }
        static void Main(string[] args)
        {
            membre UnCandidat = new membre("Donald");
            membre UnAutreCandidat = new membre("Hilary");
            membre UndernierCandidat = new membre();


            Console.WriteLine("Le second candidat est : " + UnAutreCandidat.GetName());
            Console.WriteLine("Le premier candidat est : " + UnCandidat.GetName());
            Console.WriteLine("Le dernier candidat est : " + UndernierCandidat.GetName());

            parti lePartiRepublicain = new parti("Républicain");
            parti lePartidemocrate = new parti("Démocrate");
            UnCandidat.SetParti(lePartiRepublicain);
            UndernierCandidat.SetParti(lePartidemocrate);
            UnAutreCandidat.SetParti(lePartidemocrate);

            Console.WriteLine("Le(s) membres du parti Démocrate : " + lePartidemocrate.GivelesMembres());
            Console.WriteLine("Le(s) membres du parti Républicain : " + lePartiRepublicain.GivelesMembres());
            Console.Read();
        }

    }
}