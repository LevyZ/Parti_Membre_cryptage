﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication2
{
    class membre
    {
        private string nom;
        private parti Leparti;

        public membre (string unNom)
        {
            nom = unNom;
        }

        public membre()
        {
            nom = "inconnu";
        }

        public void SetName(string unNom)
        {
            nom = unNom;
        }

        public string GetName()
        {
            return nom;
        }
   
        public void SetParti(parti UnParti)
        {
            Leparti = UnParti;
            Leparti.ajouterMembre(this);
        }
    }
}
